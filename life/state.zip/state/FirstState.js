var first_state = function () {}
first_state.prototype ={
	preload : function() {
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;

	},
	create : function() {
		this.circle = new Phaser.Circle(game.world.centerX, 100,64);
	},
	update: function() {},
	render: function() {
		game.debug.geom(this.circle,'#cfffff');
	}	
}